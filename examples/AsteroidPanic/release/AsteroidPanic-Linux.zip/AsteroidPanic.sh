#!/bin/sh
java  -jar AsteroidPanic.jar
        