#!/bin/sh
java -Xmx512m -jar MonkeyTrap.jar
        